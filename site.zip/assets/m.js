(function(){var d=document.documentElement;d.classList.add('js');
var t=document.querySelector('.top'),b=document.querySelector('.burger');if(b)b.onclick=function(){var o=t.classList.toggle('open');b.setAttribute('aria-expanded',o)};
document.querySelectorAll('.nav a').forEach(function(a){a.addEventListener('click',function(){t.classList.remove('open')})});
var els=document.querySelectorAll('.rv,.card,.row,.steps li,details,.box');
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{rootMargin:'0px 0px -8% 0px'});els.forEach(function(e){e.classList.add('rv');io.observe(e)})}
var f=document.getElementById('wa-form');if(!f)return;f.addEventListener('submit',function(e){e.preventDefault();var n=f.querySelector('[name=nom]');if(!n.value.trim()){n.focus();return}
var parts=[].map.call(f.querySelectorAll('[data-l]'),function(x){return x.value.trim()?x.getAttribute('data-l')+' : '+x.value.trim():''}).filter(Boolean);
var txt=f.getAttribute('data-intro')+'\n'+parts.join('\n');window.open('https://wa.me/237656668200?text='+encodeURIComponent(txt),'_blank','noopener');
var m=document.getElementById('wa-note');if(m)m.textContent="WhatsApp s'ouvre avec votre message. S'il ne s'ouvre pas, appelez le 656 66 82 00."})})();
